 

    
    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light mt-5 py-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="d-inline-block text-primary text-uppercase border-bottom border-5 border-secondary mb-4"> <?php the_field('heading','option') ?> </h4>
                    <p class="mb-4"><?php the_field('desc','option') ?> </p>
                    <?php 
                    $footer_contact = get_field('footer_contact','option');
                    foreach($footer_contact as $contact){
                        ?>
                          <p class="mb-2"><i class="fa <?php echo $contact['icon'] ;?> text-primary me-3"></i><?php echo $contact['address'] ;?></p>
                        <?php
                    }
                    
                    ?>
                  
                  
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="d-inline-block text-primary text-uppercase border-bottom border-5 border-secondary mb-4"><?php the_field('heading-2','option') ?></h4>
                    <div class="d-flex flex-column justify-content-start">
                    <?php 
                    $footer_page = get_field('footer_page__list','option');
                    foreach($footer_page as $page){
                        ?>
                        <a class="text-light mb-2" href="<?php the_permalink(); ?>"><i class="fa <?php echo $page['icon_'] ?> me-2"></i> <?php echo $page['page_list'] ;?></a>
                        <?php
                    }
                    ?>
                       
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="d-inline-block text-primary text-uppercase border-bottom border-5 border-secondary mb-4"><?php the_field('heading-3','option' ) ?></h4>
                    <div class="d-flex flex-column justify-content-start">
                        <?php 
                        $footer_tree = get_field('page_list','option');
                        foreach($footer_tree as $tree){
                            ?>
                             <a class="text-light mb-2" href="<?php the_permalink() ;?>"><i class="fa <?php echo $tree['icons']; ?> me-2"></i><?php echo $tree['page_name']; ?></a>
                            <?php

                        }
                        
                        ?>
                     
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="d-inline-block text-primary text-uppercase border-bottom border-5 border-secondary mb-4"><?php the_field('heading-4','option') ?></h4>
                    <form action="">
                        <div class="input-group">
                            <input type="text" class="form-control p-3 border-0" placeholder="Your Email Address">
                            <button class="btn btn-primary">Sign Up</button>
                        </div>
                    </form>
                    <h6 class="text-primary text-uppercase mt-4 mb-3"><?php the_field('sub_heading','option') ?></h6>
                    <div class="d-flex">
                    <?php 
                        $footer_socal = get_field('socal_icons','option');
                        foreach($footer_socal as $socal){
                            ?>
                             <a class="btn btn-lg btn-primary btn-lg-square rounded-circle me-2" href="<?php  echo  $socal['socal_link'];?>"><i class="fab <?php echo $socal['icon']; ?>"></i></a>
                            <?php
                        }
                        ?>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-light border-top border-secondary py-4">
        <div class="container">
            <div class="row g-5">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-md-0"> <a class="text-primary" href="#"></a> <?php the_field('copyright_title','option') ?></p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0"><?php the_field('author_title','option') ?> </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <?php wp_footer(); ?>
</body>

</html>