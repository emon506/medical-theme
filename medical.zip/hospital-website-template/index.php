<?php get_header(); ?>


    <!-- Blog Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5" style="max-width: 500px;">
                <h5 class="d-inline-block text-primary text-uppercase border-bottom border-5">Blog Post</h5>
                <h1 class="display-4">Our Latest Medical Blog Posts</h1>
            </div>
            <div class="row g-5">
            <?php 
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => 9
            );
            $query = new WP_Query($args);
               while($query-> have_posts()){
                 $query -> the_post();
                  ?>
                  <div class="col-xl-4 col-lg-6">
                    <div class="bg-light rounded overflow-hidden">
                 <?php the_post_thumbnail(); ?>
                        <div class="p-4">
                            <a class="h3 d-block mb-3" href="<?php the_permalink(); ?>"><?php the_title(); ?> </a>
                            <p class="m-0"><?php the_content(); ?></p>
                        </div>
                        <div class="d-flex justify-content-between border-top p-4">
                            <div class="d-flex align-items-center">
                                <img class="rounded-circle me-2" src="<?php echo get_template_directory_uri();?>/img/user.jpg" width="25" height="25" alt="">
                                <small><?php the_author( ); ?></small>
                            </div>
                            <div class="d-flex align-items-center">
                                <small class="ms-3"><i class="far fa-eye text-primary me-1"></i><?php $count_pages = wp_count_posts( $post_type = 'page' ); ?></small>
                                <small class="ms-3"><i class="far fa-comment text-primary me-1"></i><?php 
                                $args = array(
                                    'user_id' => 1,   
                                    'count'   => true 
                                );
                                $comments_count = get_comments( $args );
                                
                                echo $comments_count;
                                
                                ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                  <?php
               }
               ?>
               
                <div class="col-12 text-center">
                  <a href="<?php the_permalink(); ?>">  <button class="btn btn-primary py-3 px-5">Load More</button></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Blog End -->
    <?php get_footer();?>