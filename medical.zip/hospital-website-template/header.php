<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
 
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <?php wp_head(); ?>
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid py-2 border-bottom d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-lg-start mb-2 mb-lg-0">
                    <div class="d-inline-flex align-items-center">
                        <?php 
                        $phone = get_field('phone_number','option');
                        $email = get_field('email','option');
                        if( $phone){
                            ?>
                             <a class="text-decoration-none text-body pe-3" href="mailto:<?php echo $phone; ?>"><i class="bi bi-telephone me-2"></i><?php echo $phone; ?></a>
                        <span class="text-body">|</span>
                            <?php

                        }
                        if($email) {
                            ?>
                             <a class="text-decoration-none text-body px-3" href="tel:<?php echo $email; ?>"><i class="bi bi-envelope me-2"></i><?php echo $email; ?></a>
                            <?php
                        }
                        ?>
                       
                       
                    </div>
                </div>
                <div class="col-md-6 text-center text-lg-end">
                    <div class="d-inline-flex align-items-center">
                        <?php 
                        $socals_post = get_field('header_socal_icon','option');
                        foreach ($socals_post as $post){
                            ?>
                              <a class="text-body px-2" href="<?php echo $post['url'] ?>">
                            <i class="fab <?php echo $post['icon'] ?>"></i>
                        </a>
                            <?php
                        }
                        
                        ?>
                   

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid sticky-top bg-white shadow-sm mb-5">
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0">
                <a href="index.html" class="navbar-brand">
                <?php
                if ( function_exists( 'the_custom_logo' ) ) {
                    the_custom_logo();
                }
                ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
               <div class="collapse navbar-collapse" id="navbarCollapse">
                  <div class="navbar-nav ms-auto py-0">
                    <?php 
                    wp_nav_menu(array(
                        'theme_location' => 'primary-menu',
                        'menu_class' => 'navbar-nav ms-auto py-0'
                    ));
                    
                    ?>
                        
                    </div>  

                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->
    