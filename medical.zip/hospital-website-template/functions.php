<?php


// nav menu dynamic
function halim_setup(){
    add_theme_support('title-tag',);

        add_theme_support( 'custom-logo' ,[
            'header-text'          => [ 'site-title', 'site-description' ],
    'height'               => 100,
    'width'                => 400,
    'flex-height'          => true,
    'flex-width'           => true,
    'header-text'          => [ 'site-title', 'site-description' ],
   
]);
   add_theme_support('post-thumbnails',array('post'));
   
    load_theme_textdomain('halim',get_template_directory_uri().'/languages');
    
    register_nav_menus(array(
        'primary-menu' => __('primary Menu','halim'),

    ));

}
add_action('after_setup_theme','halim_setup');

function medical_theme(){
    wp_enqueue_style('font-gstatic','//fonts.gstatic.com',array(),'1.0.0','all');

    wp_enqueue_style('font-googleapis','//fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;700&family=Roboto:wght@400;700&display=swap',array(),'1.0.0','all');

    wp_enqueue_style('font-cloudflare','//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css',array(),'1.0.0','all');
    wp_enqueue_style('font-jsdelivr','//cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css',array(),'1.0.0','all');

    wp_enqueue_style('owlcarousel-css', get_template_directory_uri() .'/lib/owlcarousel/assets/owl.carousel.min.css', array(), '1.0.0','all');
    wp_enqueue_style('tempusdominus-css',get_template_directory_uri() . '/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css', array(), '1.0.0','all');
    wp_enqueue_style('bootstrap-min', get_template_directory_uri() .'/css/bootstrap.min.css', array(), '1.0.0','all');
    wp_enqueue_style('main-css',get_template_directory_uri() . '/css/style.css" rel="stylesheet', array(), '1.0.0','all');
    wp_enqueue_style('style-css',get_template_directory_uri() . '/assets/css/style.css', array(), '1.0.0','all');
   
   
    wp_enqueue_style('style', get_stylesheet_uri());


    //  js file load
    wp_enqueue_script('font-jquery','//code.jquery.com/jquery-3.4.1.min.js',array('jquery'),'1.0.0',true);
    wp_enqueue_script('font-jsdelivr','//cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js',array('jquery'),'1.0.0',true);
    wp_enqueue_script('easing', get_template_directory_uri() .'/lib/easing/easing.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('waypoints', get_template_directory_uri() .'lib/waypoints/waypoints.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('owlcarousel', get_template_directory_uri() .'/lib/owlcarousel/owl.carousel.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('tempusdominus', get_template_directory_uri() .'/lib/tempusdominus/js/moment.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('tempusdominus-js', get_template_directory_uri() .'/lib/tempusdominus/js/moment-timezone.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('lib-tempusdominus', get_template_directory_uri() .'/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js', array('jquery'), '1.0.0',true);

  
    wp_enqueue_script('main', get_template_directory_uri() .'/js/main.js', array('jquery'), '1.0.0',true);
   
  

}
add_action('wp_enqueue_scripts','medical_theme');


if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
        'page_title'    => 'Medinova Options','client',
        'menu_title'    => 'Medinova Options ','client',
        'menu_slug'     => 'Medinova-Option',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'Medinova Header Top',
        'menu_title'    => 'Header top',
        'parent_slug'   => 'Medinova-Option',
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'Medinova Footer',
        'menu_title'    => 'Footer Bottom',
        'parent_slug'   => 'Medinova-Option',
    ));
    
}